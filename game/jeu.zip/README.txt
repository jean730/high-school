##Ce dossier contient les executables pour linux et windows, les dll requis pour windows, ainsi que le code source(main.cpp) et les resources utilisées par le jeu bien rangées dans des dossiers.##
Vous êtes autorisés à redistribuer/modifier le jeu.


Le jeu dispose maintenant d'un éditeur de carte ! et bientot la possibilité de choisir parmi une liste de cartes !


#Démarer le jeu#
#
	Si vous êtes sous linux assurez vous de disposer du paquet sfml pour lancer le jeu et vous pouvez vous débarasser des dll.
	Si vous êtes sous windows vous pouvez directement lancer le jeu.
	Et si vous êtes sur mac, désolé mais je n'ai pas de version précompilée du jeu pour vous, vous allez devoir le compiler vous même :p.
#

#Compiler le jeu#
#
	Pour compiler le jeu à la main il faut disposer de la bibliothèque sfml(https://www.sfml-dev.org/) et la lier à votre compilateur.
	Si vous prévoyez d'utiliser la commande make pour compiler le jeu, veillez à d'abord modifier mon makefile à vos besoins.
#
